from django.contrib import admin
from cms.admin.placeholderadmin import PlaceholderAdmin
from models import Category, Place, Schedule, Event

admin.site.register(Category);
admin.site.register(Place);

class EventAdmin(admin.ModelAdmin):
    list_filter = ('schedule',)
admin.site.register(Event, EventAdmin)    

class EventInline(admin.StackedInline):
    model = Event

class ScheduleAdmin(admin.ModelAdmin):    
    inlines = [EventInline]
    
admin.site.register(Schedule, ScheduleAdmin)