# -*- coding: utf8 -*-
import logging
from django.db import models
from cms.models import CMSPlugin
from datetime import datetime 
# Расписание:
class Schedule(models.Model):
    title= models.CharField(verbose_name='Название',max_length=100)
    date=models.DateField(verbose_name='Дата',blank=True, null=True)
    def __unicode__(self):
        return self.title
    def getEvents(self):
        return Event.objects.filter(schedule=self).order_by("start_at_date").order_by("start_at_time")
# Место:
class Place(models.Model):
    title= models.CharField(verbose_name='Название',max_length=100)    
    slug=models.SlugField(verbose_name='Код',max_length=50)
    def __unicode__(self):
        return self.title
# Тип события:

class Category(models.Model):
    title=models.CharField(verbose_name='Название',max_length=100)
    slug=models.SlugField(verbose_name='Код',max_length=50)
    def __unicode__(self):
        return self.title
# Событие:
class Event(models.Model): 
    #Поля БД:
    schedule=models.ForeignKey(Schedule, verbose_name='Расписание')
    title=models.CharField(verbose_name='Название',max_length=100)    
    start_at_date=models.DateField(verbose_name='Дата начала', blank=True, null=True)
    start_at_time=models.TimeField(verbose_name='Время начала')    
    finish_at=models.DateTimeField(verbose_name='Время завершения',blank=True, null=True)    
    category=models.ForeignKey(Category, verbose_name='Категория')
    place=models.ForeignKey(Place, verbose_name='Место')
    description=models.TextField(verbose_name='Описание',blank=True)
    created_at=models.DateTimeField(verbose_name='Дата создание',auto_now_add=True)
    #Дата начала наследуется от расписания, но может быть переопределена
    @property
    def start_at(self):     
        if (self.start_at_date==None):
            return datetime.combine(self.schedule.date, self.start_at_time)
        else:
            return datetime.combine(self.start_at_date, self.start_at_time)
    #Флаг публикации даты:
    @property
    def is_date(self):
        if self.start_at_date:
            return self.start_at_date!=self.schedule.date
        else:
            return False 
    _url=None   
    #URL определяется как свойство:    
    def setURL(self, url):
        self._url=url
        return url
    @property
    def url(self):
        if self._url is None:            
            main=EventPlugin.objects.get(event=self, is_main=True)
            if main:
                return self.setURL(main.cmsplugin_ptr.page.get_absolute_url())
            else:
                return self.setURL(False)
        else:
            if self._url==False:
                return None
            else:
                return self._url
    def __unicode__(self):
        return self.title
    
        

class Message(models.Model):
    #Сообщение об изменении (сообщения выделяются и
    message= models.TextField(verbose_name='Сообщение')
    schedule=models.ForeignKey(Schedule, verbose_name='Расписание')
    event=models.ForeignKey(Event, verbose_name='Расписание',blank=True)
    created_at=models.DateTimeField(verbose_name='Дата сообщения',auto_now=True)
    
############ Привязка к DjangoCMS ##############
# Событие может быть расположено на странице
# Если отмечен флаг is_main данная страница считается страницей события и на нее ведут ссылки из расписания:
class EventPlugin(CMSPlugin):
    event = models.ForeignKey(Event)
    is_main= models.BooleanField('Страница события')
    def __unicode__(self):
        return self.event.__unicode__()
    @staticmethod
    def getPages(ids):
        ret={}
        for plugin in EventPlugin.objects.filter(event__in=ids, is_main=True):                    
            ret[plugin.event_id]=plugin.cmsplugin_ptr_id
        return ret
# Страница расписания:
class SchedulePlugin(CMSPlugin):    
    schedule=models.ForeignKey(Schedule)
    def __unicode__(self):
        return self.schedule

    def getEvents(self):        
        ret= self.schedule.getEvents()   
        pointers=self.fetchPointers(ret)     
        for e in ret:
            try:
                url=pointers.get(e.id)          
                if url is None:
                    #Нет ссылки на этот элемент:
                    e.setURL(False)
                else:
                    e.setURL(url)                
            except NameError:
                e.setURL('none/'+str(e.id))     
        return ret
    def fetchPointers(self, events):
        ids= list()
        for e in events:
            ids.append(e.id)        
        return EventPlugin.getPages(ids)
        
        
    