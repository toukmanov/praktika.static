# -*- coding: utf8 -*-
from cms.plugin_base import CMSPluginBase
from cms.models.pluginmodel import CMSPlugin

from cms.plugin_pool import plugin_pool
from django.utils.translation import ugettext as _

from models import SchedulePlugin, EventPlugin

#from activity.models import Category, Place, Schedule, Event
#
class CMSSchedulePlugin(CMSPluginBase):
    model = SchedulePlugin
    name = _("Schedule")
    render_template = "activity/schedule/plugin.html"    
    def render(self, context, instance, placeholder): 
        events=instance.getEvents()       
        context.update({'events':events, 'pointers':instance.fetchPointers(events)})      
        return context

plugin_pool.register_plugin(CMSSchedulePlugin)

class CMSEventPlugin(CMSPluginBase):
    model = EventPlugin
    name = _("Event")
    render_template = "activity/event/plugin.html"    
    def render(self, context, instance, placeholder):        
        context.update({'e':instance.event})      
        return context

plugin_pool.register_plugin(CMSEventPlugin)