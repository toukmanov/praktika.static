from django.db import models
# Отзыв:
class Reference(models.Model):
    name = models.CharField(max_length=100)
    about= models.CharField(max_length=100)
    body = models.CharField(max_length=250)

