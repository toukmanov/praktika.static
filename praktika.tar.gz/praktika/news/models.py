# -*- coding: utf8 -*-
import logging
from django.db import models
from cms.models import CMSPlugin
from datetime import datetime
#Элемент новости:
class News(models.Model):
    title= models.CharField(verbose_name='Название',max_length=100)
    pub_date=models.DateField(verbose_name='Дата',auto_now_add=True)
    event_date=models.DateField(verbose_name='Дата события',blank=True, null=True)
    description=models.TextField(verbose_name='Анонс')
    #Медиа:
    video= models.CharField(verbose_name='Ссылка на видео',max_length=100)
    photo= models.ImageField(upload_to='news', verbose_name='Ссылка на фотогаллерею',max_length=100)
    gallery= models.CharField(verbose_name='Ссылка на фотогаллерею',max_length=100)
    #Подробная информация может быть в тексте новости или по внешней ссылке:
    url=models.CharField(verbose_name='Ссылка',blank=True)
    body=models.TextField(verbose_name='Текст',blank=True,null=True)
    #Таксономия:
    tags=models.CharField(verbose_name='Теги',max_length=250)
    is_hidden=models.BooleanField(verbose_name='Скрыть')
    class Meta:
        verbose_name ='Новость'
        verbose_name_plural = 'Новости'
        ordering = ('-pub_date', )
    def __unicode__(self):
        return self.title