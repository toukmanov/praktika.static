# -*- coding: utf8 -*-
from django.contrib import admin
from cms.admin.placeholderadmin import PlaceholderAdmin
from praktika.news.models import News

class NewsAdmin(admin.ModelAdmin):
    search_field=('title')
    list_display = ('title', 'is_hidden', 'pub_date')

admin.site.register(News, NewsAdmin)