from django.contrib import admin
from cms.admin.placeholderadmin import PlaceholderAdmin
from praktika.contentplan.models import Phase, State


admin.site.register(Phase)
admin.site.register(State)