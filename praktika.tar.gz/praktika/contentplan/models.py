# -*- coding: utf8 -*-
from django.db import models
from cms.models import CMSPlugin, Page
# Create your models here.
class Phase(models.Model):
    title=models.CharField('Название',max_length=100)
    rank=models.IntegerField('Важность')
    start_at=models.DateField('Дата начала')
    plan_finish_at=models.DateField('Дата завершения')
    plan_finish_at=models.DateField('Фактическая дата завершения',blank=True, null=True)
    def __unicode__(self):
        return self.title
    
class State(models.Model):
    title=models.CharField('Название',max_length=100)
    is_complete=models.BooleanField('Выполнено')
    def __unicode__(self):
        return self.title
    
class Task(CMSPlugin):
    title=models.CharField('Название',max_length=100)
    state=models.ForeignKey(State)
    phase=models.ForeignKey(Phase)
    description=models.TextField('Описание')
    stub=models.TextField('Заглушка')
    def __unicode__(self):
        return self.title

