# -*- coding: utf8 -*-
from cms.models.pluginmodel import CMSPlugin
from cms.plugin_base import CMSPluginBase
from cms.plugin_pool import plugin_pool
from django.forms.fields import CharField
from models import Task
from cms.plugins.text.widgets.wymeditor_widget import WYMEditor

from django.utils.translation import ugettext as _

class CMSTaskPlugin(CMSPluginBase):
    model = Task
    name = _("Task")
    render_template = "contentplan/task/plugin.html"
    def render(self, context, instance, placeholder):
        context.update({'instance':instance})
        return context
        
    def get_editor_widget(self, request, plugins):       
        return WYMEditor(installed_plugins=plugins)    

    def get_form_class(self, request, plugins):        
        """
        Returns a subclass of Form to be used by this plugin
        """
        # We avoid mutating the Form declared above by subclassing
        class CMSTaskPluginForm(self.form):
            pass
        widget = self.get_editor_widget(request, plugins)
        CMSTaskPluginForm.declared_fields["description"] = CharField(widget=widget, required=False)
        CMSTaskPluginForm.declared_fields["stub"] = CharField(widget=widget, required=False)
        return CMSTaskPluginForm
    # Форма:
    def get_form(self, request, obj=None, **kwargs):
        plugins = plugin_pool.get_text_enabled_plugins(self.placeholder, self.page)
        form = self.get_form_class(request, plugins)
        kwargs['form'] = form # override standard form
        return super(CMSTaskPlugin, self).get_form(request, obj, **kwargs)


plugin_pool.register_plugin(CMSTaskPlugin)
