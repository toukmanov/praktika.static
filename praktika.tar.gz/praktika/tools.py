def cut(str):
    return str.__len__()
        