from django.conf.urls.defaults import *

urlpatterns = patterns('school.views',
    url(r'^$', 'test',name='test message'),
    url(r'^time/(.*)$', 'current_datetime',name='current date'),
)