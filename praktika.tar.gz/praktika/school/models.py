# -*- coding: utf8 -*-
from django.db import models
from urlparse import urlparse
#from praktika.tools import cut
from cms.models import CMSPlugin

# Create your models here.
# Consumer review:
class Review(models.Model):
    name = models.CharField('Имя/Название', max_length=100)
    description = models.CharField('Описание', max_length=100)
    body = models.TextField('Отзыв', max_length=250)   
    def __unicode__(self):
        return self.name+': '+self.body[0:10]+'...' 

class ReviewPlugin(CMSPlugin):
    review = models.ForeignKey(Review, related_name='plugins')
    def __unicode__(self):
        return self.review.name;
    
class Employee(models.Model):
    name = models.CharField('Имя', max_length=100)
    role = models.CharField('Должность', max_length=100)
    bio  = models.TextField('Биография')
    
    def __unicode__(self):
        return self.name
#Мнение сотрудника по какому-либо поводу:
class Opinion(models.Model):
    employee = models.ForeignKey(Employee, verbose_name='Сотрудник')
    role = models.CharField('Роль',max_length=100)
    body = models.TextField('Мнение', max_length=250)    
    def __unicode__(self):
        return self.employee.__unicode__()+' '+self.body[0:10]

class PageOpinion(CMSPlugin):
    employee = models.ForeignKey(Employee, verbose_name='Сотрудник')
    role = models.CharField('Роль',max_length=100)
    body = models.TextField('Мнение', max_length=250)    
    def __unicode__(self):
        return self.employee.__unicode__()+' '+self.body[0:10]
#Товар:    
class Good(models.Model):    
    name = models.CharField('Название',max_length=100)
    author=models.CharField('Автор',max_length=100)
    img = models.ImageField(verbose_name='Изображение',upload_to="good")
    slug = models.SlugField(verbose_name='URL',db_index=True)
    publisher = models.CharField('Издатель',max_length=100)
    number_of_copies = models.CharField('Тираж',max_length=20)
    ISBN = models.CharField('ISBN',max_length=20)
    def __unicode__(self):
        return self.author+' '+self.name

class GoodPlugin(CMSPlugin):
    good = models.ForeignKey(Good)
    is_main= models.BooleanField('Страница товара')
    def __unicode__(self):
        return self.good.__unicode__()

#Товар в магазине
class GoodOffer(models.Model):
    good= models.ForeignKey(Good, verbose_name='Товар')
    shop= models.CharField('Магазин', max_length=100)
    url= models.CharField('URL', max_length=100)
    price= models.PositiveSmallIntegerField('Цена')
    @property
    def icon(self):        
        url=urlparse(self.url)
        return 'http://favicon.yandex.net/favicon/'+url.hostname
    def __unicode__(self):
        return self.shop
#Курсы щколы:
class Course(models.Model):
    name = models.CharField('Название',max_length=100)
    img = models.ImageField(verbose_name='Изображение',upload_to="good")
    duration=models.CharField('Длительность',max_length=100)
    group_size=models.CharField('Количество человек в группе',max_length=50)
    schedule=models.CharField('График занятий',max_length=50)
    price=models.IntegerField('Цена')