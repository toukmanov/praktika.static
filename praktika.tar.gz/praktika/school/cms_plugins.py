# -*- coding: utf8 -*-
from cms.plugin_base import CMSPluginBase
from cms.models.pluginmodel import CMSPlugin

from cms.plugin_pool import plugin_pool
from school.models import ReviewPlugin, GoodPlugin, GoodOffer
from django.utils.translation import ugettext as _

class CMSReviewPlugin(CMSPluginBase):
    model = ReviewPlugin
    name = _("Reviews")
    render_template = "school/review/plugin.html"
    def render(self, context, instance, placeholder):
        context.update({'instance':instance,'review':instance.review})
        return context

plugin_pool.register_plugin(CMSReviewPlugin)

class CMSGoodPlugin(CMSPluginBase):
    model = GoodPlugin
    name = _("Good")
    render_template = "school/good/plugin.html"
    def render(self, context, instance, placeholder):
        if instance.is_main==False:
            main=GoodPlugin.objects.get(good= instance.good, is_main=1)
            if (main):                
                elementURL=main.cmsplugin_ptr.page.get_absolute_url()                               
            else:
                elementURL='./'
        else:
            elementURL='./'        
        context.update({'good':instance.good,
                'offers':GoodOffer.objects.filter(good= instance.good),
                'is_main':instance.is_main,
                'icons':'test1',                        
                'elementURL':elementURL
                })
        return context
    
plugin_pool.register_plugin(CMSGoodPlugin)