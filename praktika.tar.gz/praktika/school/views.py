# Create your views here.
from django.template.loader import get_template
from django.http import HttpResponse
from django.template import Context
from django.http import HttpResponse
from django.shortcuts import render_to_response
import datetime
from django.template.context import RequestContext

def test(request, *args, **kwargs):
    return render_to_response('school/test.html',{'action':'test'}, context_instance= RequestContext(request))

def current_datetime(request, arg, *args, **kwargs):    
    return HttpResponse('Datetime')

