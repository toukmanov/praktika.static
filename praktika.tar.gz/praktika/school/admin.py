from django.contrib import admin
from cms.admin.placeholderadmin import PlaceholderAdmin
from praktika.school.models import Review, Employee, Opinion, Good, GoodOffer

admin.site.register(Review)

class EmployeeAdmin(admin.ModelAdmin):
    list_display= ('name','role')
admin.site.register(Employee, EmployeeAdmin)

class OpinionAdmin(admin.ModelAdmin):
    list_display= ('employee','body')
    search_fields=('body',)
    list_filter=('employee',)
    #filter_horizontal=('employee',)
admin.site.register(Opinion, OpinionAdmin)

class GoodOfferAdmin(admin.ModelAdmin):
    list_filter = ('good',)
admin.site.register(GoodOffer, GoodOfferAdmin)    

class GoodOfferInline(admin.StackedInline):
    model = GoodOffer

class GoodAdmin(admin.ModelAdmin):
    search_field=('name','author','publisher')
    inlines = [GoodOfferInline]
admin.site.register(Good, GoodAdmin)

